package com.example.pertemuan3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
