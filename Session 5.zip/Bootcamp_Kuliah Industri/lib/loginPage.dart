import 'package:flutter/material.dart';
import 'userData.dart';
import 'appBar.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String _message = '';
  Color _messageColor = Colors.green;

  void _showMessage(String message, Color color) {
    setState(() {
      _message = message;
      _messageColor = color;
    });
  }

  void _checkLogin() {
    if (_formKey.currentState!.validate()) {
      String inputUsername = _usernameController.text;
      String inputPassword = _passwordController.text;

      bool isValid = UserData.userList.any((user) =>
      user['username'] == inputUsername && user['password'] == inputPassword);

      if (isValid) {
        _showMessage("Berhasil login", Colors.green);
      } else {
        _showMessage("Login gagal. Username atau password salah.", Colors.red); // Diubah ke merah
      }
    } else {
      _showMessage("Username dan Password tidak boleh kosong", Colors.red); // Diubah ke merah
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(),
      backgroundColor: Colors.pink,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Username Field
              TextFormField(
                controller: _usernameController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  labelText: 'Username',
                  hintText: 'Masukkan username anda',
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                validator: (value) =>
                value == null || value.isEmpty ? 'Username tidak boleh kosong' : null,
              ),

              const SizedBox(height: 20),

              // Password Field
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  labelText: 'Password',
                  hintText: 'Masukkan password anda',
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                validator: (value) =>
                value == null || value.isEmpty ? 'Password tidak boleh kosong' : null,
              ),

              const SizedBox(height: 30),

              // Login Button dengan style yang sama
              SizedBox(
                width: double.infinity,
                child: Material(
                  borderRadius: BorderRadius.circular(15),
                  color: Colors.white,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(15),
                    onTap: _checkLogin,
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      alignment: Alignment.center,
                      child: Text(
                        'LOGIN',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Poppins',
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Pesan
              if (_message.isNotEmpty)
                Text(
                  _message,
                  style: TextStyle(
                    color: _messageColor,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}