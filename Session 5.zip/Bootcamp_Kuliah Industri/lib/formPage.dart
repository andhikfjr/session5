import 'package:flutter/material.dart';
import 'appBar.dart';
import 'userData.dart';

class formPage extends StatefulWidget {
  const formPage({super.key});

  @override
  State<formPage> createState() => _FormPageState();
}

class _FormPageState extends State<formPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _namalengkapController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String _message = '';
  Color _messageColor = Colors.green;

  void _showMessage(String message, Color color) {
    setState(() {
      _message = message;
      _messageColor = color;
    });
  }

  void _handleSubmit() {
    if (_formKey.currentState!.validate()) {
      UserData.userList.add({
        'username': _usernameController.text,
        'namalengkap': _namalengkapController.text,
        'password': _passwordController.text,
      });
      _usernameController.clear();
      _namalengkapController.clear();
      _passwordController.clear();
      _showMessage('Data berhasil disimpan', Colors.green);
    } else {
      _showMessage('Data tidak boleh kosong', Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(),
      backgroundColor: Colors.pink,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Username Field
              TextFormField(
                controller: _usernameController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  labelText: 'Username',
                  hintText: 'Masukkan username anda',
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Username tidak boleh kosong' : null,
              ),
              const SizedBox(height: 20),

              // Nama Lengkap Field
              TextFormField(
                controller: _namalengkapController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  labelText: 'Nama lengkap',
                  hintText: 'Masukkan nama lengkap anda',
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Nama lengkap tidak boleh kosong' : null,
              ),
              const SizedBox(height: 20),

              // Password Field
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  labelText: 'Password',
                  hintText: 'Masukkan password anda',
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Password tidak boleh kosong' : null,
              ),
              const SizedBox(height: 30),

              // Submit Button dengan style yang sama
              SizedBox(
                width: double.infinity,
                child: Material(
                  borderRadius: BorderRadius.circular(15),
                  color: Colors.white,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(15),
                    onTap: _handleSubmit,
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      alignment: Alignment.center,
                      child: Text(
                        'SUBMIT',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Poppins',
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Pesan
              if (_message.isNotEmpty)
                Text(
                  _message,
                  style: TextStyle(
                    color: _messageColor,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}