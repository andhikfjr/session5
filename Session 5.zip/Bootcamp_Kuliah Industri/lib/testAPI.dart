import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class httpCoba extends StatefulWidget {
  @override
  _AnimeSearchAppState createState() => _AnimeSearchAppState();
}

class _AnimeSearchAppState extends State<httpCoba> {
  List<dynamic> _animes = [];
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();
  bool _isShowingTopAnime = true;

  @override
  void initState() {
    super.initState();
    _fetchTopAnimes(); // Load top anime saat pertama kali dibuka
  }

  Future<void> _fetchTopAnimes() async {
    setState(() {
      _isLoading = true;
      _isShowingTopAnime = true;
    });

    final url = Uri.parse('https://api.jikan.moe/v4/top/anime?filter=bypopularity&limit=20');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // Sort anime by score (highest to lowest)
        List<dynamic> sortedAnimes = (data['data'] as List)
            .where((anime) => anime['score'] != null)
            .toList()
          ..sort((a, b) => (b['score'] ?? 0).compareTo(a['score'] ?? 0));

        setState(() {
          _animes = sortedAnimes;
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
        _showError('Failed to load top anime. Code: ${response.statusCode}');
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _showError('Error occurred: $e');
    }
  }

  Future<void> _searchAnimes(String query) async {
    if (query.isEmpty) {
      _fetchTopAnimes();
      return;
    }

    setState(() {
      _isLoading = true;
      _isShowingTopAnime = false;
    });

    final url = Uri.parse('https://api.jikan.moe/v4/anime?q=$query&limit=20');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // Sort search results by score
        List<dynamic> sortedAnimes = (data['data'] as List)
            .where((anime) => anime['score'] != null)
            .toList()
          ..sort((a, b) => (b['score'] ?? 0).compareTo(a['score'] ?? 0));

        setState(() {
          _animes = sortedAnimes;
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
        _showError('Failed to search. Code: ${response.statusCode}');
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _showError('Error occurred: $e');
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _isShowingTopAnime
            ? Text('Top Anime by Rating')
            : Text('Search Results'),
      ),
      backgroundColor: Colors.pink,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide.none,
                      ),
                      hintText: 'Search anime...',
                      hintStyle: TextStyle(color: Colors.grey[600]),
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.search, color: Colors.grey[600]),
                        onPressed: () {
                          _searchAnimes(_searchController.text.trim());
                        },
                      ),
                    ),
                    style: TextStyle(color: Colors.black),
                    onSubmitted: (value) {
                      _searchAnimes(value.trim());
                    },
                  ),
                ),
                SizedBox(width: 8),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: IconButton(
                    icon: Icon(Icons.refresh, color: Colors.grey[600]),
                    onPressed: _fetchTopAnimes,
                    tooltip: 'Refresh top anime',
                  ),
                ),
              ],
            ),
          ),
          if (_isLoading)
            Center(child: CircularProgressIndicator())
          else if (_animes.isEmpty)
            Center(child: Text('No anime found'))
          else
            Expanded(
              child: ListView.builder(
                itemCount: _animes.length,
                itemBuilder: (context, index) {
                  final anime = _animes[index];
                  return Card(
                    margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    child: ListTile(
                      leading: anime['images']?['jpg']?['image_url'] != null
                          ? Image.network(
                        anime['images']['jpg']['image_url'],
                        width: 50,
                        height: 70,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 50,
                          height: 70,
                          color: Colors.grey,
                          child: Icon(Icons.broken_image),
                        ),
                      )
                          : Container(
                        width: 50,
                        height: 70,
                        color: Colors.grey,
                        child: Icon(Icons.movie_creation),
                      ),
                      title: Text(
                        anime['title'] ?? 'No title',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.star, color: Colors.amber, size: 16),
                              SizedBox(width: 4),
                              Text('${anime['score']?.toStringAsFixed(1) ?? 'N/A'}'),
                            ],
                          ),
                          Text('${anime['type'] ?? 'Unknown'} • ${anime['episodes'] ?? '?'} eps'),
                          if (anime['year'] != null)
                            Text('${anime['year']}'),
                        ],
                      ),
                      trailing: _isShowingTopAnime
                          ? Text('#${index + 1}', style: TextStyle(fontSize: 16))
                          : null,
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}